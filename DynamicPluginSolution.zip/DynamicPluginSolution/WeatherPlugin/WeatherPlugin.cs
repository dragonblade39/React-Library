﻿using SharedInterfaces;
using System;

namespace WeatherPlugin
{
    [Plugin("WeatherPlugin")]
    public class WeatherPlugin : IPlugin
    {
        public string Name => "WeatherPlugin";


        public void Initialize()
        {
            Console.WriteLine("Weather plugin initialized!");
        }

        public void Shutdown()
        {
            Console.WriteLine("Weather plugin shutdown!");
        }
    }
}