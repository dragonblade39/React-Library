﻿using System.Reflection;
using System.Runtime.Loader;

public class PluginLoadContext : AssemblyLoadContext
{
    private readonly AssemblyDependencyResolver _resolver;
    private readonly List<Assembly> _loadedAssemblies = new();

    public PluginLoadContext(string pluginPath) : base(isCollectible: true)
    {
        _resolver = new AssemblyDependencyResolver(pluginPath);
    }

    protected override Assembly? Load(AssemblyName assemblyName)
    {
        // Prevent loading shared dependencies into default context
        if (assemblyName.Name == "SharedInterfaces")
            return null;

        var assemblyPath = _resolver.ResolveAssemblyToPath(assemblyName);
        if (assemblyPath != null)
        {
            var assembly = LoadFromAssemblyPath(assemblyPath);
            _loadedAssemblies.Add(assembly);
            return assembly;
        }
        return null;
    }

    public new void Unload()
    {
        // Clear loaded assemblies reference
        _loadedAssemblies.Clear();
        base.Unload();
    }
}