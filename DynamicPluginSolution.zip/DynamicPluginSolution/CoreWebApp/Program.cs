﻿using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add controllers and configure application parts
var mvcBuilder = builder.Services.AddControllers();
builder.Services.AddSingleton(mvcBuilder.PartManager);

// Register PluginManager with explicit dependencies
builder.Services.AddSingleton<PluginManager>(sp =>
{
    var logger = sp.GetRequiredService<ILogger<PluginManager>>();
    var partManager = sp.GetRequiredService<ApplicationPartManager>();
    return new PluginManager(logger, partManager);
});

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("core", new OpenApiInfo { Title = "Core API", Version = "1.0" });
    c.SwaggerDoc("plugins", new OpenApiInfo { Title = "Plugins API", Version = "1.0" });

    c.DocInclusionPredicate((docName, apiDesc) =>
        docName.Equals(apiDesc.GroupName, StringComparison.OrdinalIgnoreCase));

    c.UseAllOfToExtendReferenceSchemas();
});
builder.Services.AddSingleton<IActionDescriptorChangeProvider>(ActionDescriptorChangeProvider.Instance);
// Create plugins directory
var pluginsPath = Path.Combine(builder.Environment.ContentRootPath, "Plugins");
Directory.CreateDirectory(pluginsPath);

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/core/swagger.json", "Core API");
    c.SwaggerEndpoint("/swagger/plugins/swagger.json", "Plugins API");
});

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();