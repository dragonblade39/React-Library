﻿using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationParts;

[ApiController]
[Route("api/plugins")]
[ApiExplorerSettings(GroupName = "core")]
public class PluginController : ControllerBase
{
    private readonly PluginManager _pluginManager;
    private readonly IWebHostEnvironment _env;
    private readonly ApplicationPartManager _partManager; // Added field

    public PluginController(
        PluginManager pluginManager,
        IWebHostEnvironment env,
        ApplicationPartManager partManager) // Added parameter
    {
        _pluginManager = pluginManager;
        _env = env;
        _partManager = partManager; // Initialize field
    }

    [HttpGet]
    public IActionResult GetLoadedPlugins() => Ok(_pluginManager.LoadedPlugins.Keys);

    [HttpPost("load/{pluginName}")]
    public IActionResult LoadPlugin(string pluginName)
    {
        var pluginPath = Path.Combine(_env.ContentRootPath, "Plugins", $"{pluginName}.dll");
        return _pluginManager.LoadPlugin(pluginPath) ? Ok() : NotFound();
    }

    [HttpPost("unload/{pluginName}")]
    public IActionResult UnloadPlugin(string pluginName) =>
        _pluginManager.UnloadPlugin(pluginName) ? Ok() : NotFound();

    [HttpGet("debug/parts")]
    public IActionResult GetApplicationParts()
    {
        var parts = _partManager.ApplicationParts
            .OfType<AssemblyPart>()
            .Select(p => p.Name)
            .ToList();

        return Ok(parts);
    }

        [HttpGet("assemblies")]
        public IActionResult GetLoadedAssemblies()
        {
            var assemblies = _partManager.ApplicationParts
                .OfType<AssemblyPart>()
                .Select(p => p.Name)
                .ToList();

            return Ok(assemblies);
        }

    [HttpGet("endpoints")]
    public IActionResult GetAllEndpoints()
    {
        var endpoints = _partManager.ApplicationParts
            .OfType<AssemblyPart>()
            .SelectMany(p => p.Types)
            .Where(t => typeof(ControllerBase).IsAssignableFrom(t))
            .Select(t => new {
                Controller = t.FullName,
                Routes = t.GetCustomAttributes<RouteAttribute>(true)
                    .Select(attr => attr.Template),
                Group = t.GetCustomAttributes<ApiExplorerSettingsAttribute>(true)
                    .FirstOrDefault()?.GroupName
            });

        return Ok(endpoints);
    }

}
