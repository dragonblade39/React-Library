﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using System.Collections.Concurrent;
using System.Reflection;
using SharedInterfaces;
using Microsoft.AspNetCore.Mvc.Controllers;

public class PluginManager
{
    private readonly ConcurrentDictionary<string, PluginContext> _loadedPlugins = new();
    private readonly ILogger<PluginManager> _logger;
    private readonly ApplicationPartManager _partManager;

    public PluginManager(ILogger<PluginManager> logger, ApplicationPartManager partManager)
    {
        _logger = logger;
        _partManager = partManager;
    }

    public IReadOnlyDictionary<string, PluginContext> LoadedPlugins => _loadedPlugins;

    public bool LoadPlugin(string pluginPath)
    {
        try
        {
            var loadContext = new PluginLoadContext(pluginPath);
            var assembly = loadContext.LoadFromAssemblyName(AssemblyName.GetAssemblyName(pluginPath));

            var feature = new ControllerFeature();
            _partManager.PopulateFeature(feature);

            // Controller discovery and logging
            var controllerTypes = assembly.GetExportedTypes()
                .Where(t => typeof(ControllerBase).IsAssignableFrom(t))
                .ToList();

            _logger.LogInformation("Discovered {Count} controllers in {Assembly}: {Types}",
                controllerTypes.Count,
                assembly.FullName,
                string.Join(", ", controllerTypes.Select(t => t.FullName)));

            foreach (var type in assembly.GetExportedTypes())
            {
                if (typeof(IPlugin).IsAssignableFrom(type) &&
                    type.GetCustomAttribute<PluginAttribute>() is { } attr)
                {
                    if (_loadedPlugins.ContainsKey(attr.Name))
                        throw new InvalidOperationException($"Plugin {attr.Name} already loaded");

                    var plugin = (IPlugin)Activator.CreateInstance(type)!;
                    plugin.Initialize();

                    // Add as application part
                    var part = new AssemblyPart(assembly);
                    _partManager.ApplicationParts.Add(part);
                    ActionDescriptorChangeProvider.Instance.NotifyChanged();

                    _loadedPlugins[attr.Name] = new PluginContext(
                        plugin,
                        loadContext,
                        part,
                        DateTime.UtcNow
                    );

                    return true;
                }
            }
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading plugin from {Path}", pluginPath);
            return false;
        }
    }

    public bool UnloadPlugin(string pluginName)
    {
        if (_loadedPlugins.TryRemove(pluginName, out var context))
        {
            try
            {
                context.Plugin.Shutdown();
                _partManager.ApplicationParts.Remove(context.AssemblyPart);
                ActionDescriptorChangeProvider.Instance.NotifyChanged();

                // Force garbage collection
                for (int i = 0; i < 3; i++)
                {
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }

                context.LoadContext.Unload();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error unloading plugin {Plugin}", pluginName);
                return false;
            }
        }
        return false;
    }
}

public record PluginContext(
    IPlugin Plugin,
    PluginLoadContext LoadContext,
    AssemblyPart AssemblyPart,
    DateTime LoadTime
);