﻿using SharedInterfaces;

[Plugin("SamplePlugin")]
public class SamplePlugin : IPlugin
{
    public string Name => "SamplePlugin";

    public void Initialize()
    {
        Console.WriteLine("SamplePlugin initialized!");
    }

    public void Shutdown()
    {
        Console.WriteLine("SamplePlugin shutdown!");
    }
}